Internship Tasks Submission Repository 📁

Welcome to my repository! Here, you'll find the collection of the tasks that I've completed as part of my internship experience.

🔍 Inside this repository: - Organized files for each task, with clear documentation and code.

📁 Project Description:
1. Iris Flower Prediciton

2. Movie Rating Prediction

3. Sales Prediction

4. Titanic Prediction
